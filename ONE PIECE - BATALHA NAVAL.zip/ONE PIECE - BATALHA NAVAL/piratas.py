import socket
import threading
import time
import random

def coord_to_index(coord_str):
    """Converte coordenada (Ex: 'C3') para índice (Ex: 2, 2)"""
    if len(coord_str) != 2 or not 'A' <= coord_str[0] <= 'E' or not '1' <= coord_str[1] <= '5':
        return None, None
    col = ord(coord_str[0]) - ord('A')
    row = int(coord_str[1]) - 1
    return row, col

def print_board(my_board, opponent_shots):
    """Exibe os tabuleiros do jogo"""
    header = " A B C D E"
    print("\n" + "="*50)
    print("☠️ SEU TABULEIRO (PIRATAS DO CHAPÉU DE PALHA) ☠️")
    print("="*50)
    print(header)
    for i in range(5):
        row_str = str(i + 1) + " "
        for j in range(5):
            cell = my_board[i][j]
            if cell == 'P':  # Piratas
                row_str += "P "
            elif cell == 'X':
                row_str += "X "
            else:
                row_str += ". "
        print(row_str)
    
    print("\n" + "="*50)
    print("⚔️ TIROS NA MARINHA DO GOVERNO ⚔️")
    print("="*50)
    print(header)
    for i in range(5):
        row_str = str(i + 1) + " "
        for j in range(5):
            row_str += opponent_shots[i][j] + " "
        print(row_str)
    print("-" * 50)

def setup_board():
    """Posiciona 3 navios aleatoriamente no tabuleiro dos Piratas"""
    board = [['.' for _ in range(5)] for _ in range(5)]
    ships_placed = 0
    while ships_placed < 3:
        row = random.randint(0, 4)
        col = random.randint(0, 4)
        if board[row][col] == '.':
            board[row][col] = 'P'  # Piratas
            ships_placed += 1
    return board

DIALOGOS_PIRATAS = [
    "☠️ Eu sou Luffy e vou ser Rei dos Piratas!",
    "🏴‍☠️ Você não vão conseguir nossas recompensas!",
    "⚔️ Eiiita nóis!",
    "🗡️ Zoro, Nami, todos para o combate!",
    "😍 Nami-swaaaaaaaaaaaaan, Robin-chwaaaannnn!",
]

DIALOGOS_COMBATE = [
    "💥 Gomu Gomu no Pistol! Acertamos um navio!",
    "🗡️ Técnica Santoryu! Direto no alvo!",
    "⚡ Zeus Breeze Tempo!",
    "Capitão, perdemos um navio para a Marinha!",
    "Recarreguem as armas! Contra-ataque já!",
]

GAME_STATE = {
    'meu_tabuleiro': setup_board(),
    'tabuleiro_tiros': [['.' for _ in range(5)] for _ in range(5)],
    'acertos_adversario': 0,
    'meus_acertos': 0,
    'tiros_realizados': set(),
    'running': True
}

STATE_LOCK = threading.Lock()

# --- Socket TCP ---
def connect_to_server():
    """Conecta ao servidor da Marinha"""
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    print("\n" + "="*50)
    print("☠️ PIRATAS DO CHAPÉU DE PALHA CONECTANDO...")
    print("="*50 + "\n")
    
    while True:
        try:
            client.connect(('127.0.0.1', 5000))
            print("✓ Conectado ao servidor da Marinha!\n")
            break
        except:
            print("⏳ Aguardando o servidor da Marinha iniciar...")
            time.sleep(2)
    
    return client

def opponent_turn(conn):
    """Vez do oponente atacar"""
    print("\n" + "="*50)
    print("⏳ Aguardando ataque da Marinha...")
    print("="*50 + "\n")
    
    # Recebe coordenada
    coord = conn.recv(1024).decode().strip()
    print(f"🔫 Marinha atacou em: {coord}")
    
    row, col = coord_to_index(coord)
    
    if GAME_STATE['meu_tabuleiro'][row][col] == 'P':
        print("💥 ACERTARAM! Um navio pirata foi atingido!")
        GAME_STATE['meu_tabuleiro'][row][col] = 'X'
        GAME_STATE['acertos_adversario'] += 1
        conn.send("ACERTO".encode())
        
        if GAME_STATE['acertos_adversario'] == 3:
            print("\n" + "="*50)
            print("⚓ DERROTA DOS PIRATAS! ⚓")
            print("A Marinha nos capturou!")
            print("="*50)
            GAME_STATE['running'] = False
    else:
        print("🌊 Erraram! Acertaram na água...")
        conn.send("ERRO".encode())
    
    print_board(GAME_STATE['meu_tabuleiro'], GAME_STATE['tabuleiro_tiros'])

def my_turn(conn):
    """Minha vez de atacar"""
    print("\n" + "="*50)
    print("🔫 SUA VEZ DE ATACAR!")
    print("="*50)
    print(random.choice(DIALOGOS_PIRATAS))
    
    while True:
        coord = input("\n🧭 Digite a coordenada para atacar (Ex: B2): ").upper().strip()
        
        if coord in GAME_STATE['tiros_realizados']:
            print("❌ Já atirou nessa coordenada!")
            continue
        
        row, col = coord_to_index(coord)
        if row is None:
            print("❌ Coordenada inválida! Use A-E e 1-5")
            continue
        
        GAME_STATE['tiros_realizados'].add(coord)
        break
    
    # Envia coordenada
    conn.send(coord.encode())
    print(f"\n⚡ Tiro enviado para: {coord}")
    
    # Aguarda resposta
    result = conn.recv(1024).decode()
    
    if result == "ACERTO":
        print("💥 DIRETO! Acertou um navio da Marinha!")
        print(random.choice(DIALOGOS_COMBATE))
        GAME_STATE['tabuleiro_tiros'][row][col] = 'X'
        GAME_STATE['meus_acertos'] += 1
        if GAME_STATE['meus_acertos'] == 3:
            print("\n" + "="*50)
            print("☠️ VITÓRIA DOS PIRATAS! ☠️")
            print("A Marinha foi derrotada!")
            print("="*50)
            GAME_STATE['running'] = False
    else:
        print("🌊 Erro! Acertou na água...")
        GAME_STATE['tabuleiro_tiros'][row][col] = 'A'
    
    print_board(GAME_STATE['meu_tabuleiro'], GAME_STATE['tabuleiro_tiros'])

# --- Main Loop ---
def main():
    conn = connect_to_server()
    
    try:
        turn = 0
        while GAME_STATE['running']:
            # Aguarda primeira ação da Marinha
            opponent_turn(conn)
            
            if not GAME_STATE['running']:
                break
            
            time.sleep(1)
            
            # Minha vez
            my_turn(conn)
            
            time.sleep(1)
    
    finally:
        conn.close()
        print("\n🔌 Conexão encerrada.")

if __name__ == "__main__":
    main()
