import socket
import threading
import time
import random

def coord_to_index(coord_str):
    """Converte coordenada (Ex: 'C3') para índice (Ex: 2, 2)"""
    if len(coord_str) != 2 or not 'A' <= coord_str[0] <= 'E' or not '1' <= coord_str[1] <= '5':
        return None, None
    col = ord(coord_str[0]) - ord('A')
    row = int(coord_str[1]) - 1
    return row, col

def print_board(my_board, opponent_shots):
    """Exibe os tabuleiros do jogo"""
    header = " A B C D E"
    print("\n" + "="*50)
    print("⚓ SEU TABULEIRO (MARINHA DO GOVERNO) ⚓")
    print("="*50)
    print(header)
    for i in range(5):
        row_str = str(i + 1) + " "
        for j in range(5):
            cell = my_board[i][j]
            if cell == 'M':  # Marinha
                row_str += "M "
            elif cell == 'X':
                row_str += "X "
            else:
                row_str += ". "
        print(row_str)
    
    print("\n" + "="*50)
    print("⚔️ TIROS NOS PIRATAS DO CHAPÉU DE PALHA ⚔️")
    print("="*50)
    print(header)
    for i in range(5):
        row_str = str(i + 1) + " "
        for j in range(5):
            row_str += opponent_shots[i][j] + " "
        print(row_str)
    print("-" * 50)

def setup_board():
    """Posiciona 3 navios aleatoriamente no tabuleiro da Marinha"""
    board = [['.' for _ in range(5)] for _ in range(5)]
    ships_placed = 0
    while ships_placed < 3:
        row = random.randint(0, 4)
        col = random.randint(0, 4)
        if board[row][col] == '.':
            board[row][col] = 'M'  # Marinha
            ships_placed += 1
    return board

DIALOGOS_MARINHA = [
    "⚓ Soldados da Marinha! Encontrem os piratas!",
    "🎖️ Pelo Governo! Nenhum pirata escapará!",
    "🏴‍☠️ Luffy e seus comparsas serão capturados!",
    "⚖️ Justiça sempre prevalecerá!",
    "🌊 Nenhuma fuga neste oceano!",
]

DILOGOS_COMBATE = [
    "Tiro bem direcionado! Acertamos o inimigo!",
    "Capitão, perdemos um navio!",
    "Recarreguem as armas!",
    "A Marinha está em desvantagem!",
    "Todos ao deck para defesa!",
]

GAME_STATE = {
    'vez': 1,
    'running': True,
    'meu_tabuleiro': setup_board(),
    'tabuleiro_tiros': [['.' for _ in range(5)] for _ in range(5)],
    'acertos_adversario': 0,
    'meus_acertos': 0,
    'tiros_realizados': set()
}

STATE_LOCK = threading.Lock()

# --- Socket TCP ---
def start_server():
    """Servidor TCP esperando conexão do pirata"""
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(('127.0.0.1', 5000))
    server.listen(1)
    print("\n" + "="*50)
    print("🎖️ SERVIDOR DA MARINHA INICIADO")
    print("Aguardando conexão dos Piratas...")
    print("="*50 + "\n")
    conn, addr = server.accept()
    print(f"✓ Conexão estabelecida com: {addr}")
    return conn

def my_turn(conn):
    """Minha vez de atacar"""
    print("\n" + "="*50)
    print("🔫 SUA VEZ DE ATACAR!")
    print("="*50)
    print(random.choice(DIALOGOS_MARINHA))
    
    while True:
        coord = input("\n🎯 Digite a coordenada para atacar (Ex: C3): ").upper().strip()
        
        if coord in GAME_STATE['tiros_realizados']:
            print("❌ Já atirou nessa coordenada!")
            continue
        
        row, col = coord_to_index(coord)
        if row is None:
            print("❌ Coordenada inválida! Use A-E e 1-5")
            continue
        
        GAME_STATE['tiros_realizados'].add(coord)
        break
    
    # Envia coordenada
    conn.send(coord.encode())
    print(f"\n⚡ Tiro enviado para: {coord}")
    
    # Aguarda resposta
    result = conn.recv(1024).decode()
    
    if result == "ACERTO":
        print("💥 DIRETO! Acertou um navio pirata!")
        print(random.choice(DILOGOS_COMBATE))
        GAME_STATE['tabuleiro_tiros'][row][col] = 'X'
        GAME_STATE['meus_acertos'] += 1
        if GAME_STATE['meus_acertos'] == 3:
            print("\n" + "="*50)
            print("🎖️ VITÓRIA DA MARINHA! 🎖️")
            print("Todos os piratas foram neutralizados!")
            print("="*50)
            GAME_STATE['running'] = False
    else:
        print("🌊 Erro! Acertou na água...")
        GAME_STATE['tabuleiro_tiros'][row][col] = 'A'
    
    print_board(GAME_STATE['meu_tabuleiro'], GAME_STATE['tabuleiro_tiros'])

def opponent_turn(conn):
    """Vez do oponente atacar"""
    print("\n" + "="*50)
    print("⏳ Aguardando o ataque dos Piratas...")
    print("="*50 + "\n")
    
    # Recebe coordenada
    coord = conn.recv(1024).decode().strip()
    print(f"\n🔴 Piratas atacaram em: {coord}")
    
    row, col = coord_to_index(coord)
    
    if GAME_STATE['meu_tabuleiro'][row][col] == 'M':
        print("💥 ACERTARAM! Um navio foi atingido!")
        GAME_STATE['meu_tabuleiro'][row][col] = 'X'
        GAME_STATE['acertos_adversario'] += 1
        conn.send("ACERTO".encode())
        
        if GAME_STATE['acertos_adversario'] == 3:
            print("\n" + "="*50)
            print("☠️ DERROTA DA MARINHA! ☠️")
            print("Os Piratas do Chapéu de Palha venceram!")
            print("="*50)
            GAME_STATE['running'] = False
    else:
        print("🌊 Erraram! Acertaram na água...")
        conn.send("ERRO".encode())
    
    print_board(GAME_STATE['meu_tabuleiro'], GAME_STATE['tabuleiro_tiros'])

# --- Main Loop ---
def main():
    conn = start_server()
    
    try:
        while GAME_STATE['running']:
            # Minha vez
            if GAME_STATE['vez'] == 1:
                my_turn(conn)
            
            if not GAME_STATE['running']:
                break
            
            time.sleep(1)
            
            # Vez do adversário
            if GAME_STATE['vez'] == 1:
                opponent_turn(conn)
                GAME_STATE['vez'] = 2
            else:
                GAME_STATE['vez'] = 1
            
            time.sleep(1)
    
    finally:
        conn.close()
        print("\n🔌 Conexão encerrada.")

if __name__ == "__main__":
    main()
